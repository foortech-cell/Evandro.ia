const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await b.newPage({viewport:{width:1080,height:1920}});
await p.goto('file://'+__dirname+'/film.html');await p.evaluate(()=>document.fonts.ready);
const only=process.argv[2]?process.argv[2].split(',').map(Number):null;
const N=Math.round(49.53*30);for(let i=0;i<N;i++){const t=i/30;if(only&&!only.some(x=>Math.abs(x-t)<0.017))continue;
await p.evaluate(t=>seek(t),t);await p.screenshot({path:`frames/f${String(i).padStart(4,'0')}.png`});}
await b.close();})();
