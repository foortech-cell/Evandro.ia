import numpy as np, wave, json
ev=json.load(open('ev.json'))
exec(open('sfx_base.py').read().split('t=np.arange(len(out))/SR')[0].replace('D=20.0','D=%f'%ev['end']))
D=ev['end'];t=np.arange(len(out))/SR
bed=(np.sin(2*np.pi*55*t)+.5*np.sin(2*np.pi*82.4*t)+.25*np.sin(2*np.pi*164.8*t))*.045*np.clip(t/1.5,0,1)*np.clip((D-t)/1.5,0,1); out+=bed
def kick():
    n=int(.3*SR); tt=np.arange(n)/SR; f=110*np.exp(-tt*18)+45
    return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*10)
b=7.0
while b<D-1.5:
    if not (ev['relaxa']-0.8<b<ev['relaxa']+1.2): put(kick(),b,.16); put(lp(noise(.03),.9)*env(int(.03*SR),.0005,.008),b+.27,.035)
    b+=.545
for s in ev['scenes'][1:]: put(whoosh(.35),s-.3,.3)
put(tone(1760,.5,.3),ev['scenes'][2],.12)
for t0,n,cps in ev['type']:
    for k in range(n): put(click(),t0+k/cps,.28)
for s in ev['pops']: put(tone(620,.05,.03,True),s,.1); put(click(),s,.5)
for s in ev['strike']: put(whoosh(.18),s,.25); put(tone(240,.12,.06,True),s+.05,.08)
for s in ev['clicks']: put(click(),s,.8); put(click(),s+.07,.5)
g=ev['glitch99']
for k in range(4): put(glitch(.12),g+k*.09,.6)
put(boom(1.0),g,.5)
for s in ev['boom']: put(boom(1.3),s,.6)
a,b2=ev['trema']; n=int((b2-a)*SR); rr=lp(noise(b2-a),.05)*np.sin(2*np.pi*9*np.arange(n)/SR); put(rr,a,.5)
out*=np.clip((D-t)/0.6,0,1)
out/=np.abs(out).max()/.9
w=wave.open('sfx.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((out*32767).astype(np.int16).tobytes())
