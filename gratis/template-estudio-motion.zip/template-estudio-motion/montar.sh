#!/usr/bin/env bash
# Junta os quadros, a voz e os efeitos no vídeo final.
set -e
VOZ=${1:-voz.wav}
ffmpeg -y -framerate 30 -i frames/f%04d.png -i "$VOZ" -i sfx.wav \
 -filter_complex "[1:a]aresample=48000,apad[v];[2:a]volume=0.4[s];[v][s]amix=inputs=2:duration=longest:normalize=0,loudnorm=I=-14:TP=-1.5[a]" \
 -map 0:v -map "[a]" -c:v libx264 -pix_fmt yuv420p -crf 18 -c:a aac -b:a 192k -shortest video-final.mp4
echo "Pronto: video-final.mp4"
