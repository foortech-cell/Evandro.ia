import numpy as np, wave
SR=48000; D=20.0; rng=np.random.default_rng(3); out=np.zeros(int(SR*D))
def put(s,t,g=1):
    a=int(t*SR); b=min(len(out),a+len(s))
    if a<len(out): out[a:b]+=s[:b-a]*g
def env(n,a=.002,r=.05):
    t=np.arange(n)/SR; return np.minimum(1,t/a)*np.exp(-t/r)
def tone(f,d,r=.05,sq=False):
    n=int(d*SR); x=np.sin(2*np.pi*f*np.arange(n)/SR)
    return (np.sign(x)*.6 if sq else x)*env(n,r=r)
noise=lambda d: rng.uniform(-1,1,int(d*SR))
def lp(x,a):
    y=np.zeros_like(x);acc=0.
    for i,v in enumerate(x): acc+=a*(v-acc); y[i]=acc
    return y
def glitch(d=.15):
    n=noise(d); c=np.repeat(n[::40],40)[:len(n)]
    return c*env(len(n),.001,d/2.5)
def whoosh(d=.5):
    n=noise(d); t=np.linspace(0,1,len(n)); y=np.zeros_like(n); acc=0
    for i,v in enumerate(n): acc+=(.01+.25*t[i])*(v-acc); y[i]=acc
    return y*np.sin(np.pi*t)*2.5
def boom(d=1.6):
    n=int(d*SR); t=np.arange(n)/SR; f=52*np.exp(-t*1.5)+28
    return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*2)+lp(noise(d),.05)*np.exp(-t*6)*.6
click=lambda: lp(noise(.012),.6)*env(int(.012*SR),.0005,.003)
t=np.arange(len(out))/SR
# chaos 0-4: rising noise + alarm + glitches per headline
ch=lp(noise(4.0),.3)*np.linspace(.05,.35,int(4*SR)); put(ch,0)
for k in range(8): put(glitch(.18),k*.42,.6); put(tone(900+k*80,.12,.06,True),k*.42+.02,.12)
for k in range(10): put(tone(1400 if k%2 else 1000,.18,.12,True),.2+k*.38,.08)
put(whoosh(.6),3.4,.5)
# silence then typing 4.4-5.9
for k,ch_ in enumerate("E se alguém só te explicasse?"):
    if ch_!=' ': put(click(),4.4+k*.06,.45)
put(tone(1760,.4,.25),6.2,.15)
# bed from 8s
bed=(np.sin(2*np.pi*55*t)+.6*np.sin(2*np.pi*82.4*t)+.3*np.sin(2*np.pi*110*t))*.09
bed*=np.clip((t-7.8)/.8,0,1)*np.clip((20-t)/1.0,0,1); out+=bed
def kick():
    n=int(.35*SR); tt=np.arange(n)/SR; f=120*np.exp(-tt*18)+45
    return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*9)
b=8.2
while b<19.4:
    if not (13.6<b<14.3): put(kick(),b,.35)
    b+=.475
for i in range(3):
    t0=8.2+i*1.9; put(whoosh(.35),t0-.3,.35); put(glitch(.1),t0,.4); put(tone(1300+i*200,.07,.03),t0+.05,.2); put(tone(1950+i*200,.09,.04),t0+.14,.2)
put(whoosh(.7),13.55,.45); put(boom(),14.2,.95); put(tone(1760,.6,.3),14.25,.15); put(tone(2637,.6,.35),14.3,.1)
put(glitch(.15),15.0,.3)
put(tone(2200,.08,.04),15.8,.25); put(tone(3300,.12,.06),15.9,.2)
out*=np.clip((20-t)/0.7,0,1)
out/=np.abs(out).max()/.9
w=wave.open('sfx.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((out*32767).astype(np.int16).tobytes())
