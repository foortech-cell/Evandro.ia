# Template Estúdio Motion

Modelo do vídeo "Esse vídeo foi escrito" (49 s, 13 cenas, 1080x1920, 30 fps).

1. `npm install playwright && npx playwright install chromium`
2. `mkdir frames && node rec.js` gera os quadros em `frames/`
3. `python3 sfx.py` gera os efeitos sonoros (`sfx.wav`) a partir de `ev.json`
4. Coloque a sua narração como `voz.wav` e rode `./montar.sh`

Para fazer um vídeo novo, abra o Claude Code nesta pasta e use o **prompt mestre** do capítulo 4 do manual.
`data.json` tem o tempo de cada frase e palavra; `film.html` tem a função `seek(t)` que desenha cada quadro.
