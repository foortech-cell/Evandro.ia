# Como instalar as skills

Copie cada pasta para a pasta de skills do Claude Code:

- Mac/Linux: `~/.claude/skills/`
- Windows: `C:\Users\SEU_USUARIO\.claude\skills\`

Exemplo: `~/.claude/skills/estudio-motion/SKILL.md`

Abra o Claude Code de novo. As skills são usadas sozinhas quando você pede algo parecido ("faz um vídeo animado sobre…", "corta essa live", "escreve um roteiro de Reel"). Você também pode chamar uma pelo nome: `/estudio-motion`.

