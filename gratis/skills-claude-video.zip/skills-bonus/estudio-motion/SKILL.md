---
name: estudio-motion
description: Cria Reels de texto animado no ritmo da fala (motion graphics em HTML renderizado quadro a quadro). Use quando o usuário pedir um vídeo animado, motion, vídeo de lançamento ou "um vídeo igual a esse" sem programa de edição.
---

# Estúdio Motion

Você produz vídeos 1080x1920 a 30 fps em que cada quadro é uma página HTML desenhada por uma função `seek(t)`.

## Fluxo (sempre nesta ordem)
1. **Ideia e roteiro.** De 10 a 14 frases curtas, uma por cena. Gancho na 1ª frase, chamada "comenta PALAVRA" na última. Mostre o roteiro com a ideia visual de cada cena e **espere a aprovação**.
2. **Voz.** Use o áudio que o usuário fornecer (`voz.wav`/`.mp3`). Sem áudio, gere uma voz offline (Piper) só como rascunho e avise.
3. **Tempos.** Transcreva o áudio com tempo por palavra (whisper/faster-whisper) e salve `data.json` no formato `{"lines":[{start,end,text}],"words":[{w,s,e,l}]}`. Corrija os nomes próprios pelo roteiro.
4. **Cenas.** Escreva `film.html`:
   - `window.seek(t)` desenha o estado exato no instante t. Nada de animação CSS automática nem `Date.now()`.
   - Cada palavra entra no seu tempo `s` com fade + subida + desfoque saindo (~0,2 s).
   - Misture fontes: título pesado em caixa alta, palavra de efeito em serifa itálica, detalhes em mono.
   - Câmera: leve rotação 3D que se acomoda no início de cada cena.
   - Algo muda a cada 1–2 s. Área segura: nada importante nos 250 px de cima nem nos 320 px de baixo.
   - Efeitos disponíveis: caixa de destaque, riscado, digitação com cursor, cursor-personagem com etiqueta, glitch RGB, tremor, contador com desaceleração, janela de app falsa, flash, pop com mola, balões de chat.
5. **Prévia.** Renderize 1 quadro por cena com Playwright, monte uma folha de contato, mostre e **espere a aprovação**.
6. **Render.** Gere todos os quadros (`frames/f0000.png…`).
7. **Som.** Gere `sfx.wav` por código (numpy): whoosh nas trocas de cena, cliques na digitação, pop nos elementos, glitch, boom no clímax e batida leve de fundo.
8. **Montagem.** Use ffmpeg com voz 100% e efeitos a 40%, `loudnorm=I=-14:TP=-1.5`, H.264 yuv420p crf 18.
9. **Checagem.** Confira a duração, extraia 6 quadros e veja se o texto está sincronizado e dentro da área segura.

## Regras
- Nunca copie texto, marca ou imagem de um vídeo de referência. Copie só a estrutura e o ritmo.
- Não invente números nem fatos no roteiro. Se usar dado, cite a fonte na tela.
