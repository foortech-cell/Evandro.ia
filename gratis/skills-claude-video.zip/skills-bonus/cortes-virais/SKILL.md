---
name: cortes-virais
description: Transforma um vídeo longo (live, podcast, YouTube) em cortes verticais 9:16 com título, legenda palavra por palavra, crédito e tela final. Use quando o usuário pedir cortes, clipes ou trechos de um vídeo.
---

# Cortes Virais

## Fluxo
1. **Permissão.** Pergunte se o vídeo é do usuário ou se o criador autoriza cortes. Sem autorização, não continue. Sempre dê crédito à fonte.
2. **Mapa do vídeo.**
   - Extraia o áudio a 16 kHz mono e transcreva com tempos por frase (VAD + Whisper).
   - Gere folhas de contato com 1 quadro a cada 5 s e o tempo escrito.
   - Detecte as trocas de cena (`ffmpeg scdet`).
   - Resuma os assuntos com início e fim.
3. **Seleção.** Proponha de 4 a 6 trechos de 30 a 60 s:
   - que começam e terminam no fim de uma frase (ajuste o corte para a pausa mais próxima);
   - com imagem interessante na tela;
   - que fazem sentido sozinhos.
   Dê um título curto com `{palavras}` de destaque para cada trecho. Marque boato como "NÃO CONFIRMADO". **Espere a aprovação.**
4. **Legenda.** Corrija os nomes próprios errados na transcrição. Distribua o tempo das palavras dentro de cada frase pelo número de letras. Monte a legenda em `.ass` com no máximo 4 palavras (24 caracteres) por vez e a palavra falada em destaque.
5. **Render (ffmpeg)** a 1080x1920 e 30 fps:
   - fundo com o próprio vídeo desfocado (gblur) e vídeo 16:9 no centro;
   - painel de título em cima e rodapé "FONTE: …" + "SEGUE @…";
   - barra de progresso;
   - tela final de 1,5 s;
   - whoosh de entrada e fade no áudio.
6. **Checagem.** Extraia 3 quadros por corte (início, meio, tela final) e confira o título, a legenda e o crédito.
7. **Entrega.** Entregue os .mp4 com uma legenda de post para cada corte, já com o crédito.
