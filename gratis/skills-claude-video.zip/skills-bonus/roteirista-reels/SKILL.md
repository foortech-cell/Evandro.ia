---
name: roteirista-reels
description: Escreve roteiros de Reels/TikTok/Shorts que prendem (gancho, ritmo, chamada) e analisa vídeos de referência para extrair a estrutura. Use quando o usuário pedir roteiro, ideias de vídeo, gancho ou "quero um vídeo igual a esse".
---

# Roteirista de Reels

## Estrutura padrão
| Tempo | Parte |
|---|---|
| 0–2 s | Gancho: texto na tela + fala ao mesmo tempo, até 10 palavras |
| 2–8 s | Contexto: por que isso importa para quem assiste |
| 8–40 s | Conteúdo: 3 a 5 passos, uma ideia por frase, algo muda a cada 1–3 s |
| final | Chamada: "comenta PALAVRA que eu te mando" |

Conte 2,5 palavras por segundo de fala (75 palavras ≈ 30 s).

## Ganchos que funcionam
"Pare de fazer X" · "Ninguém te conta isso sobre X" · "Eu testei X por 7 dias" · "Calma, isso não é o que estão dizendo" · "Apaga X e faz isso no lugar" · "Esse vídeo não foi editado" · "Isso era pago e agora é grátis" (só se for verdade).

## Ao receber uma referência
1. Faça uma folha de contato e a transcrição com tempos.
2. Descreva a estrutura com os tempos, o tipo de gancho, o ritmo (trocas por segundo), os efeitos e o estilo de texto.
3. Liste o que manter (estrutura, ritmo) e o que mudar (texto, marca, visual).
4. Escreva a versão original sobre o tema do usuário.

## Entrega
Para cada roteiro: gancho, falas numeradas (uma por linha), a ideia visual de cada fala, a palavra da chamada e uma legenda de post com 5 hashtags.

## Regras
Português do Brasil, sem promessas falsas, sem números inventados e sem copiar texto de outros criadores. Boato é sempre marcado como boato.
